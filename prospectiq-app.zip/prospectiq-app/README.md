# ProspectIQ AI — Multi-Tenant Lead Scraping Ecosystem

Production-ready, multi-tenant lead scraping, enrichment, and AI audit platform.

## Folder Structure

- `apps/backend`: Node.js, Express, TypeScript, Playwright, Prisma ORM, and BullMQ worker queues.
- `apps/frontend`: Standalone web dashboard built with Tailwind CSS and modular JavaScript.

## Getting Started

### 1. Backend Setup
```bash
cd apps/backend
npm install
npx playwright install chromium
npx prisma db push
npm run dev
```

### 2. Frontend Setup
Open `apps/frontend/index.html` in your browser or serve it via any static file server.
