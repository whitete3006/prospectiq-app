const API_URL = "http://localhost:3000/api";

async function fetchLeads() {
    const tenantId = document.getElementById("tenantSelect").value;
    try {
        const res = await fetch(`${API_URL}/leads?tenantId=${tenantId}`, {
            headers: { "x-tenant-id": tenantId }
        });
        const data = await res.json();
        renderTable(data.leads || []);
    } catch (err) {
        console.error("Error fetching leads:", err);
    }
}

function renderTable(leads) {
    const tbody = document.getElementById("leadsTableBody");
    if (leads.length === 0) {
        tbody.innerHTML = `<tr><td colspan="4" class="p-6 text-center text-slate-500 text-xs">No leads found for this tenant.</td></tr>`;
        return;
    }
    tbody.innerHTML = leads.map(lead => `
        <tr class="hover:bg-slate-800/30 transition">
            <td class="p-3">
                <div class="font-semibold text-white">${lead.companyName}</div>
                <div class="text-xs text-slate-400">${lead.domain}</div>
            </td>
            <td class="p-3">
                <span class="px-2 py-0.5 rounded text-xs font-bold ${lead.painScore > 75 ? 'bg-rose-950 text-rose-300 border border-rose-800' : 'bg-amber-950 text-amber-300 border border-amber-800'}">
                    ${lead.painScore} / 100
                </span>
            </td>
            <td class="p-3 text-xs">
                <div class="text-slate-200">${lead.contactName || 'N/A'}</div>
                <div class="text-slate-400">${lead.contactEmail || 'N/A'}</div>
            </td>
            <td class="p-3">
                <span class="text-xs bg-slate-800 border border-slate-700 text-slate-300 px-2 py-1 rounded">${lead.primaryTrigger}</span>
            </td>
        </tr>
    `).join('');
}

document.getElementById("scrapeForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const tenantId = document.getElementById("tenantSelect").value;
    
    await fetch(`${API_URL}/scrape`, {
        method: "POST",
        headers: { 
            "Content-Type": "application/json",
            "x-tenant-id": tenantId
        },
        body: JSON.stringify({
            niche: document.getElementById("nicheInput").value,
            location: document.getElementById("locationInput").value
        })
    });

    setTimeout(fetchLeads, 1000);
});

document.getElementById("tenantSelect").addEventListener("change", fetchLeads);
fetchLeads();
