import { Request, Response, NextFunction } from 'express';

export interface TenantRequest extends Request {
  tenantId?: string;
}

export const tenantAuth = (req: TenantRequest, res: Response, next: NextFunction) => {
  const tenantId = req.headers['x-tenant-id'] || req.query.tenantId;

  if (!tenantId) {
    return res.status(401).json({ error: 'Missing tenant context header [x-tenant-id]' });
  }

  req.tenantId = String(tenantId);
  next();
};
