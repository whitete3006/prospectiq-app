import express, { Request, Response } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { tenantAuth } from './middlewares/tenantAuth';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

interface Lead {
  id: string;
  tenantId: string;
  companyName: string;
  domain: string;
  painScore: number;
  contactName: string;
  contactEmail: string;
  primaryTrigger: string;
  createdTime: string;
}

let LEADS_DB: Lead[] = [
  {
    id: "lead-1",
    tenantId: "tenant_01",
    companyName: "Apex Dental Care",
    domain: "apexdentaltest.com",
    painScore: 88,
    contactName: "Dr. Robert Smith",
    contactEmail: "contact@apexdentaltest.com",
    primaryTrigger: "No Online Booking / Slow Mobile Score",
    createdTime: new Date().toISOString()
  }
];

app.get('/api/leads', tenantAuth, (req: Request, res: Response) => {
  const tenantId = (req as any).tenantId;
  const tenantLeads = LEADS_DB.filter(l => l.tenantId === tenantId);
  return res.json({ success: true, tenantId, count: tenantLeads.length, leads: tenantLeads });
});

app.post('/api/scrape', tenantAuth, (req: Request, res: Response) => {
  const tenantId = (req as any).tenantId;
  const { niche, location, limit = 5 } = req.body;

  const jobId = `job_${Date.now()}`;

  // Mock lead creation
  const mockLead: Lead = {
    id: `lead_${Date.now()}`,
    tenantId,
    companyName: `${location} ${niche} Pros`,
    domain: `www.${niche.toLowerCase().replace(/[^a-z]/g, '')}-demo.com`,
    painScore: Math.floor(Math.random() * 30) + 70,
    contactName: "Operations Manager",
    contactEmail: `info@${niche.toLowerCase().replace(/[^a-z]/g, '')}-demo.com`,
    primaryTrigger: "Missing SSL & Old CMS",
    createdTime: new Date().toISOString()
  };
  LEADS_DB.unshift(mockLead);

  return res.json({
    success: true,
    jobId,
    message: `Scraping job created for ${niche} in ${location}`
  });
});

app.post('/api/audit', tenantAuth, (req: Request, res: Response) => {
  const { domain, companyName, trigger } = req.body;

  const pitch = `Hi ${companyName} team, I noticed your site on ${domain} is currently missing an online instant booking module (${trigger}). We built a turn-key widget that captures 35% more inbound leads. Worth a 2-minute look?`;

  return res.json({
    success: true,
    domain,
    audit: {
      seoScore: 45,
      mobileOptimized: false,
      missingTech: ["SSL Certificate", "Schema Markup", "AI Live Chatbot"],
      generatedPitch: pitch
    }
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 ProspectIQ Backend running on http://localhost:${PORT}`);
});
